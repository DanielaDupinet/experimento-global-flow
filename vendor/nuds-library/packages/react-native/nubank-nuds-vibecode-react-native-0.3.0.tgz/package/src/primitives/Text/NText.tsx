import React from "react";
import { Text } from "react-native";
import type { TextProps, TextStyle } from "react-native";
import type { TypographyVariant } from "@nubank/nuds-vibecode-tokens";
import { useNuDSTheme } from "../../theme";

type TextTone = "primary" | "secondary" | "inverse";
type ExtendedTextTone = TextTone | "positive" | "warning" | "negative";

export type NTextProps = TextProps & {
  variant?: TypographyVariant;
  tone?: ExtendedTextTone;
  color?: string;
  tabularNumbers?: boolean;
  style?: TextStyle | TextStyle[];
};

export const NText = ({
  variant = "paragraphMediumDefault",
  tone = "primary",
  color,
  tabularNumbers = false,
  style,
  ...rest
}: NTextProps) => {
  const theme = useNuDSTheme();

  const colorMap: Record<ExtendedTextTone, string> = {
    inverse: theme.color.content.main,
    secondary: theme.color.content.secondary,
    primary: theme.color.content.primary,
    positive: theme.color.positive,
    warning: theme.color.warning,
    negative: theme.color.negative
  };
  const isLabelVariant = variant.startsWith("label");
  const shouldUseTabular = tabularNumbers || isLabelVariant;

  return (
    <Text
      style={[
        theme.typography[variant],
        {
          color: color ?? colorMap[tone],
          fontVariant: shouldUseTabular ? ["tabular-nums", "lining-nums"] : undefined
        },
        style
      ]}
      {...rest}
    />
  );
};
