import React, { useEffect, useRef } from "react";
import { Animated, Dimensions, Modal, Pressable, View } from "react-native";
import type { StyleProp, ViewStyle } from "react-native";
import { TopBar } from "../../components/TopBar";
import { ListRow } from "../../components/ListRow";
import { useNuDSTheme } from "../../theme";

const SCREEN_HEIGHT = Dimensions.get("window").height;
const ANIMATION_DURATION = 300;

export type ActionSheetItem = {
  key: string;
  label: string;
  icon?: React.ReactNode;
  onPress: () => void;
  disabled?: boolean;
  accessibilityLabel?: string;
};

export type ActionSheetProps = {
  visible: boolean;
  onClose: () => void;
  title?: string;
  actions: ActionSheetItem[];
  style?: StyleProp<ViewStyle>;
};

export const ActionSheet = ({
  visible,
  onClose,
  title = "More actions",
  actions,
  style
}: ActionSheetProps) => {
  const theme = useNuDSTheme();
  const overlayAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(SCREEN_HEIGHT)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(overlayAnim, {
          toValue: 1,
          duration: ANIMATION_DURATION,
          useNativeDriver: true
        }),
        Animated.spring(slideAnim, {
          toValue: 0,
          damping: 20,
          stiffness: 200,
          mass: 0.8,
          useNativeDriver: true
        })
      ]).start();
    }
  }, [visible]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(overlayAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true
      }),
      Animated.timing(slideAnim, {
        toValue: SCREEN_HEIGHT,
        duration: 250,
        useNativeDriver: true
      })
    ]).start(() => {
      onClose();
    });
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={handleClose}
      statusBarTranslucent
    >
      {/* Overlay — fades in */}
      <Animated.View
        style={{
          ...({ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 } as ViewStyle),
          backgroundColor: theme.color.background.overlay,
          opacity: overlayAnim
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Close"
          onPress={handleClose}
          style={{ flex: 1 }}
        />
      </Animated.View>

      {/* Bottom sheet — slides up */}
      <Animated.View
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          transform: [{ translateY: slideAnim }]
        }}
      >
        <Pressable onPress={() => {}}>
          <View
            style={[
              {
                backgroundColor: theme.color.background.primary,
                borderTopLeftRadius: theme.radius.xxl,
                borderTopRightRadius: theme.radius.xxl
              },
              style
            ]}
          >
            {/* Handle bar */}
            <View
              style={{
                alignItems: "center",
                paddingTop: theme.spacing[1]
              }}
            >
              <View
                style={{
                  width: 36,
                  height: 4,
                  borderRadius: theme.radius.sm,
                  backgroundColor: theme.color.border.secondary
                }}
              />
            </View>

            {/* Header */}
            <TopBar
              variant="modal"
              title={title}
              show1stAction={false}
              show2ndAction={false}
              showStatusBar={false}
              onBackPress={handleClose}
            />

            {/* Action list */}
            <View
              style={{
                paddingHorizontal: theme.spacing[4],
                paddingBottom: theme.spacing[3]
              }}
            >
              <View
                style={{
                  backgroundColor: theme.color.background.primary,
                  borderWidth: 1,
                  borderColor: theme.color.border.secondary,
                  borderRadius: theme.radius.xl,
                  paddingVertical: theme.spacing[1],
                  overflow: "hidden",
                  ...theme.elevation.level1
                }}
              >
                {actions.map((action, index) => (
                  <ListRow
                    key={action.key}
                    label={action.label}
                    leading={action.icon}
                    disabled={action.disabled}
                    accessibilityLabel={action.accessibilityLabel}
                    showDivider={index < actions.length - 1}
                    onPress={() => {
                      action.onPress();
                      handleClose();
                    }}
                  />
                ))}
              </View>
            </View>
          </View>
        </Pressable>
      </Animated.View>
    </Modal>
  );
};
