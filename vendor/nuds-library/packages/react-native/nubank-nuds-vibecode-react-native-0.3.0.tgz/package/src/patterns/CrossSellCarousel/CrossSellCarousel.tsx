import React, { useCallback, useRef, useState } from "react";
import { Animated, Pressable, ScrollView, View } from "react-native";
import type { ViewStyle } from "react-native";
import { NText } from "../../primitives/Text";
import { CloseMiniIcon } from "../../icons/CloseMiniIcon";
import { SectionTitle } from "../../components/SectionTitle";
import { useNuDSTheme } from "../../theme";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type CrossSellBanner = {
  key: string;
  /** Leading icon element (20 px recommended) */
  icon?: React.ReactNode;
  /** Offer description text */
  text: string;
  /** Called when the banner is tapped */
  onPress?: () => void;
  /** Called after the banner has been dismissed (animation finished) */
  onDismiss?: () => void;
};

export type CrossSellCarouselProps = {
  /** Array of banner offers to display */
  items: CrossSellBanner[];
  /**
   * When `true`, each banner shows a dismiss (×) button that fades the
   * banner out on tap. Once every banner is dismissed the whole carousel
   * collapses so no blank space remains.
   * @default false
   */
  dismissible?: boolean;
  /**
   * When provided, renders a compact SectionTitle above the carousel.
   * The title automatically disappears when all banners are dismissed.
   */
  sectionTitle?: string;
  /** Called when every banner has been dismissed */
  onAllDismissed?: () => void;
  style?: ViewStyle | ViewStyle[];
};

// ---------------------------------------------------------------------------
// Animated banner wrapper
// ---------------------------------------------------------------------------

type AnimatedBannerProps = {
  item: CrossSellBanner;
  dismissible: boolean;
  bannerBg: string;
  bannerTextColor: string;
  isSingle: boolean;
  onDismissed: (key: string) => void;
};

const ANIMATION_DURATION = 250;

const AnimatedBanner = ({
  item,
  dismissible,
  bannerBg,
  bannerTextColor,
  isSingle,
  onDismissed,
}: AnimatedBannerProps) => {
  const theme = useNuDSTheme();
  const opacity = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(1)).current;

  const handleDismiss = useCallback(() => {
    Animated.parallel([
      Animated.timing(opacity, {
        toValue: 0,
        duration: ANIMATION_DURATION,
        useNativeDriver: true,
      }),
      Animated.timing(scale, {
        toValue: 0.9,
        duration: ANIMATION_DURATION,
        useNativeDriver: true,
      }),
    ]).start(() => {
      item.onDismiss?.();
      onDismissed(item.key);
    });
  }, [item, onDismissed, opacity, scale]);

  const bannerContent = (
    <View
      style={{
        flexDirection: "row",
        alignItems: "flex-start",
        gap: theme.spacing[2],
        backgroundColor: bannerBg,
        borderRadius: theme.radius.xl,
        padding: theme.spacing[3],
        minHeight: 60,
        width: 299,
      }}
    >
      {/* Leading icon */}
      {item.icon ? (
        <View style={{ width: 20, height: 20, flexShrink: 0 }}>
          {item.icon}
        </View>
      ) : null}

      {/* Text */}
      <View style={{ flex: 1 }}>
        <NText
          variant="labelSmallStrong"
          color={bannerTextColor}
        >
          {item.text}
        </NText>
      </View>

      {/* Dismiss button — only when dismissible variant */}
      {dismissible ? (
        <Pressable
          onPress={handleDismiss}
          accessibilityRole="button"
          accessibilityLabel="Dismiss offer"
          hitSlop={8}
          style={{
            width: 32,
            height: 32,
            flexShrink: 0,
            alignItems: "center",
            justifyContent: "center",
            marginTop: -4,
            marginRight: -4,
          }}
        >
          <CloseMiniIcon size={20} color={bannerTextColor} />
        </Pressable>
      ) : null}
    </View>
  );

  const wrappedContent = item.onPress ? (
    <Pressable onPress={item.onPress}>{bannerContent}</Pressable>
  ) : (
    bannerContent
  );

  return (
    <Animated.View style={{ opacity, transform: [{ scale }] }}>
      {wrappedContent}
    </Animated.View>
  );
};

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export const CrossSellCarousel = ({
  items,
  dismissible = false,
  sectionTitle,
  onAllDismissed,
  style,
}: CrossSellCarouselProps) => {
  const theme = useNuDSTheme();

  // Track which banners have been dismissed
  const [dismissedKeys, setDismissedKeys] = useState<Set<string>>(new Set());

  // Animate the whole container collapsing
  const containerHeight = useRef(new Animated.Value(1)).current;
  const [collapsed, setCollapsed] = useState(false);

  const handleBannerDismissed = useCallback(
    (key: string) => {
      setDismissedKeys((prev) => {
        const next = new Set(prev);
        next.add(key);

        // Check if all items are now dismissed
        if (next.size >= items.length) {
          // Collapse the container
          Animated.timing(containerHeight, {
            toValue: 0,
            duration: ANIMATION_DURATION,
            useNativeDriver: false, // height animation can't use native driver
          }).start(() => {
            setCollapsed(true);
            onAllDismissed?.();
          });
        }

        return next;
      });
    },
    [items.length, containerHeight, onAllDismissed]
  );

  if (!items || items.length === 0 || collapsed) return null;

  const bannerBg = theme.color.background.secondary;
  const bannerTextColor = theme.color.main;

  const visibleItems = items.filter((i) => !dismissedKeys.has(i.key));
  const isSingle = visibleItems.length <= 1;

  return (
    <Animated.View
      style={[
        {
          opacity: containerHeight, // 1 → 0
          transform: [{ scaleY: containerHeight }],
        },
        style,
      ]}
    >
      {/* Section title — auto-hides when all banners are dismissed */}
      {sectionTitle ? (
        <SectionTitle title={sectionTitle} compact />
      ) : null}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: theme.spacing[4],
          paddingBottom: theme.spacing[3],
          gap: theme.spacing[3],
        }}
      >
        {visibleItems.map((item) => (
          <AnimatedBanner
            key={item.key}
            item={item}
            dismissible={dismissible}
            bannerBg={bannerBg}
            bannerTextColor={bannerTextColor}
            isSingle={isSingle}
            onDismissed={handleBannerDismissed}
          />
        ))}
      </ScrollView>
    </Animated.View>
  );
};
