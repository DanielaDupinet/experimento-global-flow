import React from "react";
import { Image, View } from "react-native";
import type { ImageSourcePropType, StyleProp, ViewStyle } from "react-native";
import { NText } from "../../primitives/Text";
import { useNuDSTheme } from "../../theme";
import type { TypographyVariant } from "@nubank/nuds-vibecode-tokens";

// ── Size tokens ──────────────────────────────────────────────────────
const SIZE_MAP = {
  xsmall: 24,
  small: 32,
  medium: 40,
  large: 64,
} as const;

const ICON_SIZE_MAP = {
  xsmall: 12,
  small: 16,
  medium: 20,
  large: 32,
} as const;

const INITIALS_VARIANT_MAP: Record<AvatarSize, TypographyVariant> = {
  xsmall: "label2XSmallStrong",
  small: "labelXSmallStrong",
  medium: "labelSmallStrong",
  large: "subtitleMediumStrong",
};

// ── Types ────────────────────────────────────────────────────────────
export type AvatarSize = "xsmall" | "small" | "medium" | "large";
export type AvatarVariant = "icon" | "image" | "initials";

export type AvatarProps = {
  /** Visual variant */
  variant?: AvatarVariant;
  /** Size preset */
  size?: AvatarSize;
  /** Icon node — used when variant="icon" */
  icon?: React.ReactNode;
  /** Image source — used when variant="image" */
  imageSource?: ImageSourcePropType;
  /** 1–2 letter initials — used when variant="initials" */
  initials?: string;
  /** Use accent background for initials (purple tint) */
  onSubtle?: boolean;
  /** Show a small notification dot badge */
  showNotificationDot?: boolean;
  /** Disabled state — reduces opacity */
  disabled?: boolean;
  /** Custom style on the outer container */
  style?: StyleProp<ViewStyle>;
};

export const Avatar = ({
  variant = "icon",
  size = "small",
  icon,
  imageSource,
  initials = "AA",
  onSubtle = false,
  showNotificationDot = false,
  disabled = false,
  style,
}: AvatarProps) => {
  const theme = useNuDSTheme();

  const dimension = SIZE_MAP[size];
  const iconSize = ICON_SIZE_MAP[size];
  const initialsTypo = INITIALS_VARIANT_MAP[size];

  // Background for icon / initials variants
  const circleBackground =
    variant === "initials" && onSubtle
      ? theme.color.content.selection // light purple (brand[10])
      : theme.color.background.secondary; // neutral grey

  return (
    <View
      style={[
        {
          width: dimension,
          height: dimension,
          borderRadius: dimension / 2,
          overflow: "hidden",
          alignItems: "center",
          justifyContent: "center",
          opacity: disabled ? 0.4 : 1,
        },
        style,
      ]}
    >
      {/* ── Image variant ── */}
      {variant === "image" && imageSource ? (
        <>
          <Image
            source={imageSource}
            style={{
              width: dimension,
              height: dimension,
              borderRadius: dimension / 2,
            }}
            resizeMode="cover"
          />
          {/* Subtle overlay matching Figma */}
          <View
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              borderRadius: dimension / 2,
              backgroundColor: "rgba(31, 2, 48, 0.04)",
            }}
          />
        </>
      ) : null}

      {/* ── Icon variant ── */}
      {variant === "icon" ? (
        <>
          <View
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              borderRadius: dimension / 2,
              backgroundColor: circleBackground,
            }}
          />
          {icon ? (
            <View
              style={{
                width: iconSize,
                height: iconSize,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {icon}
            </View>
          ) : null}
        </>
      ) : null}

      {/* ── Initials variant ── */}
      {variant === "initials" ? (
        <>
          <View
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              borderRadius: dimension / 2,
              backgroundColor: circleBackground,
            }}
          />
          <NText
            variant={initialsTypo}
            style={{
              color: disabled
                ? theme.color.content.disabled
                : theme.color.content.primary,
              textAlign: "center",
            }}
          >
            {initials.slice(0, 2).toUpperCase()}
          </NText>
        </>
      ) : null}

      {/* ── Notification dot badge ── */}
      {showNotificationDot && !disabled ? (
        <View
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            width: 8,
            height: 8,
            borderRadius: 4,
            backgroundColor: theme.color.accent,
            borderWidth: 2,
            borderColor: theme.color.background.primary,
          }}
        />
      ) : null}
    </View>
  );
};
