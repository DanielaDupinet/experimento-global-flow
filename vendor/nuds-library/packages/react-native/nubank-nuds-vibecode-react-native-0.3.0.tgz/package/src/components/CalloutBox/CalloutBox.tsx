import React from "react";
import { Pressable, View } from "react-native";
import type { StyleProp, ViewStyle } from "react-native";
import { NText } from "../../primitives/Text";
import { ButtonLink } from "../ButtonLink";
import { CloseIcon } from "../../icons/CloseIcon";
import { ArrowRightIcon } from "../../icons/ArrowRightIcon";
import { useNuDSTheme } from "../../theme";
import styles from "./styles";

export type CalloutBoxProps = {
  /** Bold title text */
  title: string;
  /** Optional description text below the title */
  description?: string;
  /** Optional action link label (renders a compact ButtonLink with arrow) */
  actionLabel?: string;
  /** Called when the action link is pressed */
  onActionPress?: () => void;
  /** Called when the dismiss (X) button is pressed */
  onDismiss?: () => void;
  /** Custom style applied to the outer container */
  style?: StyleProp<ViewStyle>;
};

export const CalloutBox = ({
  title,
  description,
  actionLabel,
  onActionPress,
  onDismiss,
  style,
}: CalloutBoxProps) => {
  const theme = useNuDSTheme();

  const hasAction = Boolean(actionLabel);
  // When there's no action link, match top padding so it looks balanced.
  // When there IS an action, the ButtonLink's own height adds visual weight,
  // so we use a tighter bottom padding.
  const bottomPadding = hasAction ? theme.spacing[1] : theme.spacing[5];

  return (
    <View
      style={[
        styles.outer,
        {
          paddingHorizontal: theme.spacing[4], // 16
          paddingVertical: theme.spacing[3], // 12
        },
        style,
      ]}
    >
      <View
        style={[
          styles.wrapper,
          {
            backgroundColor: "rgba(240, 238, 241, 0.4)",
            borderRadius: theme.radius.xl, // 24
            paddingTop: theme.spacing[5], // 20
            paddingBottom: bottomPadding,
          },
        ]}
      >
        {/* Content area */}
        <View
          style={[
            styles.container,
            {
              paddingLeft: theme.spacing[5], // 20
              paddingRight: theme.spacing[12], // 48 — room for dismiss button
            },
          ]}
        >
          <View style={styles.content}>
            {/* Text box (title + description) */}
            <View style={[styles.textBox, { gap: theme.spacing[1] }]}>
              <NText variant="subtitleSmallStrong" color={theme.color.content.primary}>
                {title}
              </NText>

              {description ? (
                <NText variant="paragraphSmallDefault" color={theme.color.content.secondary}>
                  {description}
                </NText>
              ) : null}
            </View>

            {/* Action link */}
            {actionLabel ? (
              <View style={[styles.actions, { gap: theme.spacing[2] }]}>
                <ButtonLink
                  label={actionLabel}
                  compact
                  trailingIcon={<ArrowRightIcon />}
                  onPress={onActionPress}
                />
              </View>
            ) : null}
          </View>
        </View>

        {/* Dismiss button */}
        {onDismiss ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Dismiss"
            onPress={onDismiss}
            style={[
              styles.dismissButton,
              {
                borderRadius: theme.radius.full, // 64
              },
            ]}
          >
            <CloseIcon size={20} color={theme.color.content.secondary} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
};
