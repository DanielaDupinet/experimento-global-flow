import React from "react";
import { View } from "react-native";
import type { ViewStyle } from "react-native";
import { NText } from "../../primitives/Text";
import { useNuDSTheme } from "../../theme";

type BadgeColor = "accent" | "neutral" | "success" | "attention" | "critical";

export type BadgeProps = {
  /** Text displayed inside the badge */
  label?: string;
  /** Semantic color variant */
  color?: BadgeColor;
  /** When false, renders in disabled/N-A style regardless of color */
  enabled?: boolean;
  /** Use slightly darker background for placement on subtle surfaces */
  onSubtle?: boolean;
  style?: ViewStyle | ViewStyle[];
};

// Badge-specific surface & content colors from Figma spec.
// These are not yet in the token system — promote when stabilised.
const BADGE_COLORS = {
  accent: {
    bg: "#f6ecff",
    bgSubtle: "#ecd9ff",
  },
  neutral: {
    bg: "#f0eef1",
    bgSubtle: "#e3e0e5",
  },
  success: {
    bg: "#ddf5e5",
    bgSubtle: "#bcebcc",
  },
  attention: {
    bg: "#ffecd6",
    bgSubtle: "#ffdab1",
  },
  critical: {
    bg: "#ffeae8",
    bgSubtle: "#ffd8d5",
  },
  disabled: {
    bg: "#f0eef1",
    bgSubtle: "#e3e0e5",
  },
} as const;

export const Badge = ({
  label = "Label",
  color = "accent",
  enabled = true,
  onSubtle = false,
  style,
}: BadgeProps) => {
  const theme = useNuDSTheme();

  const resolvedColor = enabled ? color : "disabled";
  const colors = BADGE_COLORS[resolvedColor];
  const backgroundColor = onSubtle ? colors.bgSubtle : colors.bg;

  const textColor = enabled
    ? {
        accent: theme.color.main,
        neutral: theme.color.content.secondary,
        success: theme.color.positive,
        attention: theme.color.warning,
        critical: theme.color.negative,
      }[color]
    : theme.color.content.disabled;

  return (
    <View
      style={[
        {
          alignSelf: "flex-start",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          paddingHorizontal: theme.spacing[2],
          paddingVertical: 2,
          borderRadius: theme.radius.md,
          backgroundColor,
          minHeight: 20,
          maxWidth: 359,
          overflow: "hidden",
        },
        style,
      ]}
      accessibilityRole="text"
    >
      <NText
        variant="labelXSmallStrong"
        numberOfLines={1}
        style={{ color: textColor, textAlign: "center" }}
      >
        {label}
      </NText>
    </View>
  );
};
