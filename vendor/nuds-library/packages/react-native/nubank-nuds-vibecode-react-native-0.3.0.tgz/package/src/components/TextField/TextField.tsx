import React from "react";
import { TextInput, View } from "react-native";
import type { TextInputProps, ViewStyle } from "react-native";
import { Field } from "../../primitives/Field";
import { useNuDSTheme } from "../../theme";

export type TextFieldProps = Omit<TextInputProps, "style"> & {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
};

export const TextField = ({
  label,
  hint,
  error,
  required,
  leading,
  trailing,
  editable = true,
  style,
  ...rest
}: TextFieldProps) => {
  const theme = useNuDSTheme();
  const hasError = Boolean(error);

  return (
    <Field label={label} hint={hint} error={error} required={required}>
      <View
        style={[
          {
            minHeight: 48,
            borderRadius: theme.radius.md,
            borderWidth: 1,
            borderColor: hasError ? theme.color.negative : theme.color.border.primary,
            backgroundColor: editable ? theme.color.background.primary : theme.color.background.disabled,
            paddingHorizontal: theme.spacing[3],
            gap: theme.spacing[2],
            alignItems: "center",
            flexDirection: "row"
          },
          style
        ]}
      >
        {leading}
        <TextInput
          style={[
            {
              flex: 1,
              color: theme.color.content.primary
            },
            theme.typography.paragraphSmallDefault
          ]}
          placeholderTextColor={theme.color.content.secondary}
          editable={editable}
          {...rest}
        />
        {trailing}
      </View>
    </Field>
  );
};
