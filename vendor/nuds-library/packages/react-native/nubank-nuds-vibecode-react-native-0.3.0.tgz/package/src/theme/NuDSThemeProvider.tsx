import React, { createContext, useContext, useMemo } from "react";
import type { ReactNode } from "react";
import { darkTheme, lightTheme, type NuDSTheme } from "@nubank/nuds-vibecode-theme";

type NuDSThemeContextValue = {
  theme: NuDSTheme;
};

const NuDSThemeContext = createContext<NuDSThemeContextValue>({
  theme: lightTheme
});

export type NuDSThemeProviderProps = {
  mode?: "light" | "dark";
  themeOverride?: NuDSTheme;
  children: ReactNode;
};

export const NuDSThemeProvider = ({
  mode = "light",
  themeOverride,
  children
}: NuDSThemeProviderProps) => {
  const theme = useMemo(() => {
    if (themeOverride) {
      return themeOverride;
    }
    return mode === "dark" ? darkTheme : lightTheme;
  }, [mode, themeOverride]);

  return (
    <NuDSThemeContext.Provider value={{ theme }}>
      {children}
    </NuDSThemeContext.Provider>
  );
};

export const useNuDSTheme = (): NuDSTheme => {
  return useContext(NuDSThemeContext).theme;
};
