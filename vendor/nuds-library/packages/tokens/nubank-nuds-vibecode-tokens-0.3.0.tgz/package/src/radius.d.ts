export declare const radius: {
    readonly none: 0;
    readonly sm: 4;
    readonly md: 8;
    readonly lg: 16;
    readonly xl: 24;
    readonly xxl: 32;
    readonly full: 64;
};
//# sourceMappingURL=radius.d.ts.map