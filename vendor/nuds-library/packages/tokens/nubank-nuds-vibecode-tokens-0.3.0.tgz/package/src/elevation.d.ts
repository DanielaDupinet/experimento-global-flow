export declare const elevation: {
    readonly none: {
        readonly shadowColor: "transparent";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 0;
        };
        readonly shadowOpacity: 0;
        readonly shadowRadius: 0;
        readonly elevation: 0;
    };
    readonly level1: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 1;
        };
        readonly shadowOpacity: 0.12;
        readonly shadowRadius: 2;
        readonly elevation: 1;
    };
    readonly level2: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 2;
        };
        readonly shadowOpacity: 0.16;
        readonly shadowRadius: 4;
        readonly elevation: 2;
    };
    readonly level3: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 3;
        };
        readonly shadowOpacity: 0.2;
        readonly shadowRadius: 8;
        readonly elevation: 4;
    };
    readonly sticky: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 2;
        };
        readonly shadowOpacity: 0.12;
        readonly shadowRadius: 8;
        readonly elevation: 3;
    };
    readonly dropdown: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 4;
        };
        readonly shadowOpacity: 0.16;
        readonly shadowRadius: 12;
        readonly elevation: 6;
    };
    readonly modal: {
        readonly shadowColor: "#000000";
        readonly shadowOffset: {
            readonly width: 0;
            readonly height: 8;
        };
        readonly shadowOpacity: 0.2;
        readonly shadowRadius: 20;
        readonly elevation: 10;
    };
};
//# sourceMappingURL=elevation.d.ts.map