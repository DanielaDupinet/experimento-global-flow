export declare const spacing: {
    readonly 0: 0;
    readonly 1: 4;
    readonly 2: 8;
    readonly 3: 12;
    readonly 4: 16;
    readonly 5: 20;
    readonly 6: 24;
    readonly 7: 28;
    readonly 8: 32;
    readonly 9: 36;
    readonly 10: 40;
    readonly 11: 44;
    readonly 12: 48;
    readonly 16: 64;
    readonly 20: 80;
    readonly 24: 96;
};
export type SpacingKey = keyof typeof spacing;
//# sourceMappingURL=spacing.d.ts.map