// Core palette seeded from Prometheus-MVP and NuDS conventions.
export const palette = {
    transparent: "transparent",
    white: "#FFFFFF",
    black: "#000000",
    brand: {
        10: "#F9E7FF",
        20: "#EAC2FF",
        30: "#CF8CFC",
        40: "#AB4BEA",
        50: "#820AD1",
        60: "#6200A3",
        70: "#480078",
        80: "#330055",
        90: "#23003A",
        100: "#170027"
    },
    neutral: {
        0: "#FFFFFF",
        10: "#F5F3F6",
        20: "#EFEFEF",
        30: "#D8DAE0",
        40: "#B7BAC3",
        50: "#8F929D",
        60: "#727683",
        70: "#40424A",
        80: "#23242A",
        90: "#1F0230",
        100: "#100D11"
    },
    success: {
        50: "#4AA46E",
        60: "#1F7F45",
        70: "#045B27"
    },
    warning: {
        50: "#FE7D21",
        60: "#C95400",
        70: "#963F00"
    },
    danger: {
        50: "#D72923",
        60: "#A90700",
        70: "#7C0600"
    }
};
export const semanticLight = {
    main: palette.brand[50],
    mainFeedback: palette.brand[60],
    accent: palette.brand[40],
    accentFeedback: palette.brand[50],
    content: {
        main: palette.white,
        mainFeedback: "rgba(255,255,255,0.9)",
        primary: palette.neutral[90],
        primaryFeedback: palette.neutral[100],
        secondary: "rgba(31, 2, 48, 0.62)",
        secondaryFeedback: "rgba(31, 2, 48, 0.78)",
        disabled: palette.neutral[40],
        selection: palette.brand[10],
        inverse: palette.white,
        tertiary: "rgba(31, 2, 48, 0.46)"
    },
    background: {
        screen: palette.white,
        primary: palette.white,
        primaryFeedback: palette.neutral[10],
        secondary: palette.neutral[10],
        secondaryFeedback: palette.neutral[20],
        disabled: palette.neutral[20],
        overlay: "rgba(16, 13, 17, 0.45)",
        elevated: palette.white
    },
    border: {
        primary: "rgba(31, 0, 47, 0.16)",
        primaryFeedback: "rgba(31, 0, 47, 0.24)",
        secondary: "rgba(31, 0, 47, 0.08)",
        secondaryFeedback: "rgba(31, 0, 47, 0.16)",
        focus: palette.brand[50]
    },
    positive: palette.success[60],
    positiveFeedback: palette.success[70],
    warning: palette.warning[60],
    warningFeedback: palette.warning[70],
    negative: palette.danger[50],
    negativeFeedback: palette.danger[60]
};
export const semanticDark = {
    main: "#B676CF",
    mainFeedback: "#8A5A9C",
    accent: "#9E67B8",
    accentFeedback: "#B676CF",
    content: {
        main: palette.black,
        mainFeedback: "rgba(0,0,0,0.9)",
        primary: "#EDE9EE",
        primaryFeedback: "#F9F8FA",
        secondary: "#938997",
        secondaryFeedback: "#B9B0BD",
        disabled: "#433B46",
        selection: "#241F26",
        inverse: palette.black,
        tertiary: "#7B717F"
    },
    background: {
        screen: "#100D11",
        primary: "#100D11",
        primaryFeedback: "#241F26",
        secondary: "#241F26",
        secondaryFeedback: "#433B46",
        disabled: "#241F26",
        overlay: "rgba(0, 0, 0, 0.6)",
        elevated: "#1B171D"
    },
    border: {
        primary: "#938997",
        primaryFeedback: "#B9B0BD",
        secondary: "#433B46",
        secondaryFeedback: "#695F6D",
        focus: "#B676CF"
    },
    positive: "#4E8A66",
    positiveFeedback: "#39634A",
    warning: "#DA8B57",
    warningFeedback: "#8E5233",
    negative: "#D77976",
    negativeFeedback: "#A35E5B"
};
//# sourceMappingURL=color.js.map