export declare const zIndex: {
    readonly base: 0;
    readonly sticky: 100;
    readonly dropdown: 200;
    readonly popover: 300;
    readonly overlay: 1000;
    readonly sheet: 1500;
    readonly modal: 2000;
    readonly toast: 3000;
    readonly tooltip: 4000;
};
//# sourceMappingURL=zIndex.d.ts.map