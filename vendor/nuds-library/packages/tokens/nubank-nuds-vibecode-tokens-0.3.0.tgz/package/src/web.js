import { semanticDark, semanticLight } from "./color";
const flattenObject = (value, prefix = []) => {
    const out = [];
    Object.entries(value).forEach(([key, current]) => {
        const path = [...prefix, key];
        if (typeof current === "string" ||
            typeof current === "number") {
            out.push([path.join("-"), current]);
            return;
        }
        if (current && typeof current === "object") {
            out.push(...flattenObject(current, path));
        }
    });
    return out;
};
export const createCssVariables = (mode = "light") => {
    const target = mode === "light" ? semanticLight : semanticDark;
    const entries = flattenObject(target);
    const lines = entries.map(([key, val]) => `  --nuds-${key}: ${String(val)};`);
    return `:root {\n${lines.join("\n")}\n}`;
};
//# sourceMappingURL=web.js.map