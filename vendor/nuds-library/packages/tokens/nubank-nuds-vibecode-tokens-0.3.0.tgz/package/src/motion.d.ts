export declare const duration: {
    readonly t100: 100;
    readonly t200: 200;
    readonly t300: 300;
    readonly t400: 400;
    readonly t500: 500;
    readonly t600: 600;
    readonly t700: 700;
    readonly t800: 800;
    readonly t900: 900;
    readonly t1000: 1000;
};
export declare const motion: {
    readonly linear: {
        readonly quick: 100;
        readonly medium: 200;
        readonly slow: 300;
    };
    readonly main: {
        readonly quick: 200;
        readonly medium: 300;
        readonly slow: 400;
    };
    readonly entering: {
        readonly quick: 200;
        readonly medium: 300;
        readonly slow: 400;
    };
    readonly exiting: {
        readonly quick: 100;
        readonly medium: 200;
        readonly slow: 300;
    };
};
//# sourceMappingURL=motion.d.ts.map