export declare const createCssVariables: (mode?: "light" | "dark") => string;
//# sourceMappingURL=web.d.ts.map