export declare const fontFamily: {
    readonly display: {
        readonly regular: "NuSansDisplay-Regular";
        readonly medium: "NuSansDisplay-Medium";
        readonly semibold: "NuSansDisplay-Semibold";
        readonly bold: "NuSansDisplay-Semibold";
    };
    readonly text: {
        readonly regular: "NuSansText-Regular";
        readonly medium: "NuSansText-Medium";
        readonly semibold: "NuSansText-Semibold";
        readonly bold: "NuSansText-Bold";
    };
    readonly legacy: {
        readonly regular: "Nu Sans";
        readonly medium: "Nu Sans Medium";
    };
};
export declare const typography: {
    readonly titleXLarge: {
        readonly fontFamily: "NuSansDisplay-Medium";
        readonly fontSize: 44;
        readonly lineHeight: 48.4;
    };
    readonly titleLarge: {
        readonly fontFamily: "NuSansDisplay-Medium";
        readonly fontSize: 36;
        readonly lineHeight: 39.6;
    };
    readonly titleMedium: {
        readonly fontFamily: "NuSansDisplay-Medium";
        readonly fontSize: 28;
        readonly lineHeight: 33.6;
    };
    readonly titleSmall: {
        readonly fontFamily: "NuSansDisplay-Medium";
        readonly fontSize: 24;
        readonly lineHeight: 28.8;
    };
    readonly titleXSmall: {
        readonly fontFamily: "NuSansDisplay-Medium";
        readonly fontSize: 20;
        readonly lineHeight: 24;
    };
    readonly subtitleMediumDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 18;
        readonly lineHeight: 23.4;
    };
    readonly subtitleMediumStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 18;
        readonly lineHeight: 23.4;
    };
    readonly subtitleSmallDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 16;
        readonly lineHeight: 20.8;
    };
    readonly subtitleSmallStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 16;
        readonly lineHeight: 20.8;
    };
    readonly paragraphMediumDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 16;
        readonly lineHeight: 24;
    };
    readonly paragraphMediumStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 16;
        readonly lineHeight: 24;
    };
    readonly paragraphSmallDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 14;
        readonly lineHeight: 21;
    };
    readonly paragraphSmallStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 14;
        readonly lineHeight: 21;
    };
    readonly labelMediumDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 16;
        readonly lineHeight: 20.8;
    };
    readonly labelMediumStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 16;
        readonly lineHeight: 20.8;
    };
    readonly labelSmallDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 14;
        readonly lineHeight: 18.2;
    };
    readonly labelSmallStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 14;
        readonly lineHeight: 18.2;
    };
    readonly labelXSmallDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 12;
        readonly lineHeight: 15.6;
        readonly letterSpacing: 0.12;
    };
    readonly labelXSmallStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 12;
        readonly lineHeight: 15.6;
        readonly letterSpacing: 0.12;
    };
    readonly label2XSmallDefault: {
        readonly fontFamily: "NuSansText-Regular";
        readonly fontSize: 10;
        readonly lineHeight: 13;
        readonly letterSpacing: 0.1;
    };
    readonly label2XSmallStrong: {
        readonly fontFamily: "NuSansText-Semibold";
        readonly fontSize: 10;
        readonly lineHeight: 13;
        readonly letterSpacing: 0.1;
    };
};
export type TypographyVariant = keyof typeof typography;
//# sourceMappingURL=typography.d.ts.map