export declare const palette: {
    readonly transparent: "transparent";
    readonly white: "#FFFFFF";
    readonly black: "#000000";
    readonly brand: {
        readonly 10: "#F9E7FF";
        readonly 20: "#EAC2FF";
        readonly 30: "#CF8CFC";
        readonly 40: "#AB4BEA";
        readonly 50: "#820AD1";
        readonly 60: "#6200A3";
        readonly 70: "#480078";
        readonly 80: "#330055";
        readonly 90: "#23003A";
        readonly 100: "#170027";
    };
    readonly neutral: {
        readonly 0: "#FFFFFF";
        readonly 10: "#F5F3F6";
        readonly 20: "#EFEFEF";
        readonly 30: "#D8DAE0";
        readonly 40: "#B7BAC3";
        readonly 50: "#8F929D";
        readonly 60: "#727683";
        readonly 70: "#40424A";
        readonly 80: "#23242A";
        readonly 90: "#1F0230";
        readonly 100: "#100D11";
    };
    readonly success: {
        readonly 50: "#4AA46E";
        readonly 60: "#1F7F45";
        readonly 70: "#045B27";
    };
    readonly warning: {
        readonly 50: "#FE7D21";
        readonly 60: "#C95400";
        readonly 70: "#963F00";
    };
    readonly danger: {
        readonly 50: "#D72923";
        readonly 60: "#A90700";
        readonly 70: "#7C0600";
    };
};
export declare const semanticLight: {
    readonly main: "#820AD1";
    readonly mainFeedback: "#6200A3";
    readonly accent: "#AB4BEA";
    readonly accentFeedback: "#820AD1";
    readonly content: {
        readonly main: "#FFFFFF";
        readonly mainFeedback: "rgba(255,255,255,0.9)";
        readonly primary: "#1F0230";
        readonly primaryFeedback: "#100D11";
        readonly secondary: "rgba(31, 2, 48, 0.62)";
        readonly secondaryFeedback: "rgba(31, 2, 48, 0.78)";
        readonly disabled: "#B7BAC3";
        readonly selection: "#F9E7FF";
        readonly inverse: "#FFFFFF";
        readonly tertiary: "rgba(31, 2, 48, 0.46)";
    };
    readonly background: {
        readonly screen: "#FFFFFF";
        readonly primary: "#FFFFFF";
        readonly primaryFeedback: "#F5F3F6";
        readonly secondary: "#F5F3F6";
        readonly secondaryFeedback: "#EFEFEF";
        readonly disabled: "#EFEFEF";
        readonly overlay: "rgba(16, 13, 17, 0.45)";
        readonly elevated: "#FFFFFF";
    };
    readonly border: {
        readonly primary: "rgba(31, 0, 47, 0.16)";
        readonly primaryFeedback: "rgba(31, 0, 47, 0.24)";
        readonly secondary: "rgba(31, 0, 47, 0.08)";
        readonly secondaryFeedback: "rgba(31, 0, 47, 0.16)";
        readonly focus: "#820AD1";
    };
    readonly positive: "#1F7F45";
    readonly positiveFeedback: "#045B27";
    readonly warning: "#C95400";
    readonly warningFeedback: "#963F00";
    readonly negative: "#D72923";
    readonly negativeFeedback: "#A90700";
};
export declare const semanticDark: {
    readonly main: "#B676CF";
    readonly mainFeedback: "#8A5A9C";
    readonly accent: "#9E67B8";
    readonly accentFeedback: "#B676CF";
    readonly content: {
        readonly main: "#000000";
        readonly mainFeedback: "rgba(0,0,0,0.9)";
        readonly primary: "#EDE9EE";
        readonly primaryFeedback: "#F9F8FA";
        readonly secondary: "#938997";
        readonly secondaryFeedback: "#B9B0BD";
        readonly disabled: "#433B46";
        readonly selection: "#241F26";
        readonly inverse: "#000000";
        readonly tertiary: "#7B717F";
    };
    readonly background: {
        readonly screen: "#100D11";
        readonly primary: "#100D11";
        readonly primaryFeedback: "#241F26";
        readonly secondary: "#241F26";
        readonly secondaryFeedback: "#433B46";
        readonly disabled: "#241F26";
        readonly overlay: "rgba(0, 0, 0, 0.6)";
        readonly elevated: "#1B171D";
    };
    readonly border: {
        readonly primary: "#938997";
        readonly primaryFeedback: "#B9B0BD";
        readonly secondary: "#433B46";
        readonly secondaryFeedback: "#695F6D";
        readonly focus: "#B676CF";
    };
    readonly positive: "#4E8A66";
    readonly positiveFeedback: "#39634A";
    readonly warning: "#DA8B57";
    readonly warningFeedback: "#8E5233";
    readonly negative: "#D77976";
    readonly negativeFeedback: "#A35E5B";
};
type SemanticColorShape<T> = {
    [K in keyof T]: T[K] extends Record<string, unknown> ? SemanticColorShape<T[K]> : string;
};
export type SemanticColor = SemanticColorShape<typeof semanticLight>;
export {};
//# sourceMappingURL=color.d.ts.map