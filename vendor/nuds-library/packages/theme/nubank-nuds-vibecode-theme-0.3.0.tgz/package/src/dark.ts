import {
  elevation,
  motion,
  radius,
  semanticDark,
  spacing,
  typography,
  zIndex
} from "@nubank/nuds-vibecode-tokens";
import type { NuDSTheme } from "./types";

export const darkTheme: NuDSTheme = {
  mode: "dark",
  color: semanticDark,
  spacing,
  radius,
  motion,
  typography,
  elevation,
  zIndex
};
