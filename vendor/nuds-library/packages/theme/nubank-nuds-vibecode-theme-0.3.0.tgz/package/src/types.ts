import type {
  SemanticColor,
  spacing,
  radius,
  motion,
  typography,
  elevation,
  zIndex
} from "@nubank/nuds-vibecode-tokens";

export type NuDSTheme = {
  mode: "light" | "dark";
  color: SemanticColor;
  spacing: typeof spacing;
  radius: typeof radius;
  motion: typeof motion;
  typography: typeof typography;
  elevation: typeof elevation;
  zIndex: typeof zIndex;
};
