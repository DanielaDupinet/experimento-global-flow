import {
  elevation,
  motion,
  radius,
  semanticLight,
  spacing,
  typography,
  zIndex
} from "@nubank/nuds-vibecode-tokens";
import type { NuDSTheme } from "./types";

export const lightTheme: NuDSTheme = {
  mode: "light",
  color: semanticLight,
  spacing,
  radius,
  motion,
  typography,
  elevation,
  zIndex
};
